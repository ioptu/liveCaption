// js/content.js

let subtitleDiv     = null;
let subtitlePanel   = null; // 【改动】原来是 splitContainer(leftPanel+splitter+rightPanel)，
                             // 现在是单栏容器，不再左右分屏
let scrollBtn       = null;
let dragHandle      = null;
let closeBtn        = null;

let isDraggingContainer  = false;
let containerOffsetX, containerOffsetY;

// 渲染节流变量
// 【改动】原来用单槽位 pendingData 做节流，后到的消息会直接覆盖还没
// 处理的旧消息——这对“未定稿实时刷新”这种本来就该互相覆盖的更新没问题，
// 但现在多了“定稿原文”和“译文补丁”这两种互相独立、缺一不可的消息，
// 单槽位覆盖会导致同一动画帧里到达的多条消息只有最后一条被处理，
// 前面的凭空消失（实测复现：pairId=5 的译文补丁被紧跟着到达的
// pairId=6 定稿消息覆盖掉，从头到尾没有被渲染过）。
// 现在拆成两部分：
//   pendingFinals：定稿/译文补丁消息，用数组排队，一条都不能丢
//   pendingInterim：未定稿更新，只需要保留最新一条，跟原来行为一致
let pendingFinals          = [];
let pendingInterim         = null;
let isAnimationFrameActive = false;

function getTargetContainer() {
    const fsElement = document.fullscreenElement ||
                      document.webkitFullscreenElement ||
                      document.mozFullScreenElement;
    if (fsElement) {
        return fsElement.shadowRoot || fsElement;
    }
    return document.body;
}

function createOverlay() {
    const containerId = 'sszm-subtitle-container';
    if (document.getElementById(containerId)) return;

    subtitleDiv = document.createElement('div');
    subtitleDiv.id = containerId;

    dragHandle = document.createElement('div');
    dragHandle.id = 'sszm-drag-handle';

    closeBtn = document.createElement('div');
    closeBtn.id = 'sszm-close-btn';
    closeBtn.innerHTML = '✕';
    closeBtn.title = '关闭字幕';
    closeBtn.style.cssText = `
        position: absolute;
        top: 6px;
        right: 12px;
        width: 20px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        color: rgba(255, 255, 255, 0.5);
        font-size: 14px;
        cursor: pointer;
        z-index: 100;
        font-family: Arial, sans-serif;
        border-radius: 50%;
        background: rgba(0, 0, 0, 0.3);
        transition: all 0.2s ease;
    `;
    closeBtn.onmouseover = () => {
        closeBtn.style.color = '#fff';
        closeBtn.style.background = 'rgba(255, 82, 82, 0.9)';
    };
    closeBtn.onmouseout = () => {
        closeBtn.style.color = 'rgba(255, 255, 255, 0.5)';
        closeBtn.style.background = 'rgba(0, 0, 0, 0.3)';
    };

    // 【改动】不再创建 splitContainer/leftPanel/splitter/rightPanel，
    // 原文和译文现在共享同一个单栏容器，一段原文紧跟一段译文。
    subtitlePanel = document.createElement('div');
    subtitlePanel.id = 'sszm-subtitle-panel';

    scrollBtn = document.createElement('button');
    scrollBtn.id = 'sszm-scroll-bottom-btn';
    scrollBtn.innerText = '↓ 回到底部';

    subtitleDiv.appendChild(closeBtn);
    subtitleDiv.appendChild(dragHandle);
    subtitleDiv.appendChild(subtitlePanel);
    subtitleDiv.appendChild(scrollBtn);

    const target = getTargetContainer();
    target.appendChild(subtitleDiv);

    setupEventListeners();
}

function handleFullscreenChange() {
    if (!subtitleDiv) return;
    const newTarget = getTargetContainer();
    if (subtitleDiv.parentElement !== newTarget) {
        newTarget.appendChild(subtitleDiv);
    }
}

document.addEventListener('fullscreenchange',       handleFullscreenChange);
document.addEventListener('webkitfullscreenchange', handleFullscreenChange);

function clearSubtitleContent() {
    if (subtitlePanel) subtitlePanel.innerHTML = '';
}

function setupEventListeners() {
    if (closeBtn) {
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            chrome.runtime.sendMessage({ type: 'stop-capture' });
            subtitleDiv.style.display = 'none';
            clearSubtitleContent();
        });
    }

    dragHandle.addEventListener('mousedown', (e) => {
        isDraggingContainer = true;
        const rect = subtitleDiv.getBoundingClientRect();
        containerOffsetX = e.clientX - rect.left;
        containerOffsetY = e.clientY - rect.top;
        e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
        if (isDraggingContainer) {
            let x = e.clientX - containerOffsetX;
            let y = e.clientY - containerOffsetY;
            subtitleDiv.style.left   = `${x}px`;
            subtitleDiv.style.top    = `${y}px`;
            subtitleDiv.style.bottom = 'auto';
        }
    });

    document.addEventListener('mouseup', () => { isDraggingContainer = false; });

    // 【改动】不再需要分割线拖拽逻辑（isResizingSplitter 那一整块），
    // 只剩单栏面板的滚动监听。
    let scrollTimeout;
    const updateScrollButton = () => {
        if (scrollTimeout) return;
        scrollTimeout = setTimeout(() => {
            const dist = subtitlePanel.scrollHeight - subtitlePanel.scrollTop - subtitlePanel.clientHeight;
            if (dist > 50) {
                scrollBtn.classList.add('show');
            } else {
                scrollBtn.classList.remove('show');
            }
            scrollTimeout = null;
        }, 150);
    };

    subtitlePanel.addEventListener('scroll', updateScrollButton);

    scrollBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        subtitlePanel.scrollTo({ top: subtitlePanel.scrollHeight, behavior: 'smooth' });
        scrollBtn.classList.remove('show');
    });
}

// ── 单栏“原文+译文”成对显示 ────────────────────────────────────
// 【改动】取消左右分屏，原文和译文现在合并到同一个容器里，一段原文
// 紧跟着它的译文，再接下一段原文……因为 offscreen.js 那边 isbreak 和
// tisbreak 本来就是同一个 shouldBreak 值（原文译文永远同时定稿），
// 所以“一对”天然是对齐的，不需要处理两边异步错位的情况。
//
// 每一“段”是一个 <div class="sszm-pair"> 包着两个子 div
// （.sszm-pair-original / .sszm-pair-translation），上色只需要设置
// 在 .sszm-pair 这一层，两个子元素没有自己的颜色会自动继承。
//
// 三档“特殊上色”：
//   最新一段   → 浅黄
//   倒数第二段 → 棕色
//   最旧一段   → 紫色（这里的“最旧”指“上色窗口里最旧”，不是整个历史里最旧）
// 未定稿的那一段固定用金色，标识“这句还没说完”。
const HISTORY_COLORS = ['#E6DC84']; // [最新, 倒数第二, 最旧]
const COLOR_WINDOW = HISTORY_COLORS.length; // 只有最近这几段会被特殊上色

// 【改动】历史保留量改回按“段数”控制（不是行数、也不是单条原文/译文
// 各自的条数，是“原文+译文”一整对算一段）。默认 5 段，改成 Infinity
// 即可不限制——裁剪循环用 > 比较，n > Infinity 恒为 false，等价于
// 直接跳过裁剪，不需要额外分支处理。
let PAIR_CAP = 10;

const CURRENT_PAIR_CLASS = 'sszm-current-pair';
const CURRENT_PAIR_COLOR = '#ffeb3b'; // 与原 .current-line 颜色保持一致

function createPairElement(className) {
    const pair = document.createElement('div');
    pair.className = className;
    const orig = document.createElement('div');
    orig.className = 'sszm-pair-original';
    const trans = document.createElement('div');
    trans.className = 'sszm-pair-translation';
    pair.appendChild(orig);
    pair.appendChild(trans);
    return pair;
}

// 确保容器末尾始终有且仅有一个“未定稿”段落对，返回它。
function ensureCurrentPair(container) {
    let cur = container.querySelector(`:scope > .${CURRENT_PAIR_CLASS}`);
    if (!cur) {
        cur = createPairElement(CURRENT_PAIR_CLASS);
        cur.style.color = CURRENT_PAIR_COLOR;
        cur.style.fontWeight = '500';
        container.appendChild(cur);
    } else if (cur !== container.lastElementChild) {
        container.appendChild(cur);
    }
    return cur;
}

// 更新“未定稿”这一段的原文/译文内容（每次 onresult 都会调用）
function updateCurrentPair(container, text, translatedText) {
    if (!container) return;
    const cur = ensureCurrentPair(container);
    cur.firstElementChild.textContent = text || '';
    cur.lastElementChild.textContent  = translatedText || '';
}

// 把当前这一对原文+译文转正为一段正式的历史记录，插入到“未定稿”段之前。
// 【改动】译文现在可能还没翻译好（offscreen.js 那边把定稿的原文和译文
// 拆成了两条消息，原文先上屏，译文翻译完再单独补发）。这里传入的
// translatedText 可能是空字符串，pairId 打在这段元素的 data 属性上，
// 供后面 updatePairTranslation() 找到这一段去补上译文。
// 【性能】上色和裁剪都不遍历全部历史，开销恒定：上色只碰“新插入的这段”
// 往前数 COLOR_WINDOW 个 + 刚掉出窗口的那 1 个；裁剪用 childElementCount
// 判断，正常情况下每次最多删 1 段。
function finalizePairIntoHistory(container, text, translatedText, pairId) {
    if (!container || !text) return;
    const cur = ensureCurrentPair(container);

    const pair = createPairElement('sszm-pair');
    pair.firstElementChild.textContent = text;
    pair.lastElementChild.textContent  = translatedText || '';
    if (pairId != null) pair.dataset.pairId = String(pairId);
    container.insertBefore(pair, cur);

    cur.firstElementChild.textContent = '';
    cur.lastElementChild.textContent  = '';

    // 只重新上色最近 COLOR_WINDOW 段，从新插入的这段开始往前数
    let node = pair;
    for (let i = 0; i < COLOR_WINDOW && node; i++) {
        node.style.color = HISTORY_COLORS[i];
        node = node.previousElementSibling;
    }
    // node 现在是“刚掉出上色窗口”的那一段（如果存在），恢复默认色
    if (node) node.style.color = '';

    // 按段数裁剪（-1 排除末尾的未定稿段）
    while (container.childElementCount - 1 > PAIR_CAP) {
        const oldest = container.firstElementChild;
        if (!oldest || oldest === cur) break;
        container.removeChild(oldest);
    }
}

// 【新增】译文翻译完之后单独补发的更新——不创建新段落，只找到 pairId
// 对应的那一段，把译文填进去。如果那一段已经因为裁剪（超过 PAIR_CAP）
// 被移除了，这里直接静默跳过，不报错——翻译结果晚到、对应内容已经
// 滚出历史区，属于正常情况。
function updatePairTranslation(container, pairId, translatedText) {
    if (!container || pairId == null) return;
    const pair = container.querySelector(`:scope > .sszm-pair[data-pair-id="${pairId}"]`);
    //console.log(`[诊断][content.js] 收到 pairId=${pairId} 的译文补丁，${pair ? '找到对应段落，已更新' : '没找到对应段落（可能已被裁剪掉）'}`);
    if (!pair) return;
    pair.lastElementChild.textContent = translatedText || '';
}

function renderFrame() {
    if (!subtitlePanel) {
        // 【修复】若 DOM 元素尚未就绪（极罕见的时序问题），跳过本帧，
        // 保留队列内容，下一帧继续尝试，不能直接清空——不然排队的消息
        // 也会跟着丢掉。
        isAnimationFrameActive = false;
        if (pendingFinals.length > 0 || pendingInterim) {
            isAnimationFrameActive = true;
            requestAnimationFrame(renderFrame);
        }
        return;
    }

    // 先处理这一批全部排队的定稿/译文补丁消息，一条都不跳过
    while (pendingFinals.length > 0) {
        const data = pendingFinals.shift();
        const { text, translatedText, isbreak, tisbreak, pairId } = data;
        if (isbreak && text?.trim()) {
            // 原文定稿：立刻上屏，译文可能还没好（translatedText 可能是空的）
            finalizePairIntoHistory(subtitlePanel, text, translatedText, pairId);
        } else if (tisbreak && pairId != null) {
            // 译文单独补到之前已经上屏的那一段，不影响“当前行”
            updatePairTranslation(subtitlePanel, pairId, translatedText);
        }
    }

    // 未定稿只需要渲染最新的一条，中间态可以丢
    if (pendingInterim) {
        const { text, translatedText } = pendingInterim;
        updateCurrentPair(subtitlePanel, text, translatedText);
        pendingInterim = null;
    }

    // 【修复】scrollBtn null 检查，防止 TypeError 中断渲染循环
    if (scrollBtn && !scrollBtn.classList.contains('show')) {
        subtitlePanel.scrollTop = subtitlePanel.scrollHeight;
    }

    isAnimationFrameActive = false;
}



chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // 【修复】非 subtitle-update 消息必须返回 false（而不是 undefined），
    // 明确告知 Chrome 该监听器不处理此消息，防止 Chrome 在某些版本中
    // 将 undefined 返回值与异常混淆，从而静默禁用整个监听器。
    if (msg.type !== 'subtitle-update') return false;

    try {
        if (!subtitleDiv) createOverlay();
    } catch (e) {
        console.error('[sszm] createOverlay 异常:', e);
        return false;
    }

    if (msg.status === 'stopped') {
        if (subtitleDiv) subtitleDiv.style.display = 'none';
        clearSubtitleContent();
        pendingFinals  = [];
        pendingInterim = null;
        // 【修复】stopped 分支也要 sendResponse，避免 background 侧 channel 报错
        sendResponse({ status: "ok" });
        return true;
    }

    if (subtitleDiv) subtitleDiv.style.display = 'flex';

    // 【改动】定稿/译文补丁消息进队列排队，一条都不能丢；
    // 未定稿消息只保留最新一条，覆盖旧的就行。
    if (msg.isbreak || msg.tisbreak) {
        pendingFinals.push(msg);
    } else {
        pendingInterim = msg;
    }

    if (!isAnimationFrameActive) {
        isAnimationFrameActive = true;
        requestAnimationFrame(renderFrame);
    }

    sendResponse({ status: "ok" });
    return true;
});