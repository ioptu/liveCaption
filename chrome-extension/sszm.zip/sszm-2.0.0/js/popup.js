// js/popup.js
const startBtn   = document.getElementById('startBtn');
const stopBtn    = document.getElementById('stopBtn');
const statusDiv  = document.getElementById('status');
const langSelect = document.getElementById('language');

let isRunning = false;

// ════════════════════════════════════════════════════════════
// 【新增】离线语音识别模型（SODA）的可用性检测 + 下载
// ════════════════════════════════════════════════════════════
// 【关键】install() 必须在用户手势的同步调用链里触发，一旦经过
// chrome.runtime.sendMessage 转发到 background/offscreen 再调用，
// 浏览器会报 "Requires handling a user gesture" 错误。
// 所以这一步必须放在 popup.js 的按钮 click 回调里，紧跟在点击之后，
// 不能等 start-capture 消息发出去之后才在 offscreen 里做。
const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;

// 【更正】之前这里按 Edge 官方文档把候选语言砍到 6 种，是想窄了——
// 这是个 Chrome/Edge 通用扩展，两个浏览器各自维护自己的语言模型表，
// 不是同一份数据。Chrome 官方规范 explainer 实际支持的语言范围明显更大
// （包含 zh-CN/zh-TW/ja-JP/fr-FR/ru-RU 等），Edge 目前只有 6 种。
// 与其在代码里猜哪个浏览器支持什么，不如把候选语言恢复成产品原本想
// 支持的范围，实际能不能用完全交给下面 available() 的运行时探测结果——
// 同一份代码在 Chrome 上和 Edge 上探测出来的可用语言本来就应该不一样。
const SPEECH_LANG_MAP = {
  en: 'en-US',
  ja: 'ja-JP',
  ko: 'ko-KR',
  fr: 'fr-FR',
  de: 'de-DE',
  ru: 'ru-RU',
  es: 'es-ES',
  zh: 'zh-CN',
};
function toBcp47(lang) {
  return SPEECH_LANG_MAP[lang] || lang || 'en-US';
}

// 【已排查清楚】曾怀疑 quality:'conversation' 是关键，实测证明不是——
// 这个档位在当前浏览器版本上对所有语言都是 unavailable，且不传 track
// 直接走系统麦克风也一样报 language-not-supported，说明这纯粹是
// available() 和 start() 的实现不一致，跟 quality/track 都无关。
// 保留 toBcp47 的映射逻辑即可，不再需要额外的诊断探测。

/**
 * 在用户点击 Start 的同一调用链里完成离线模型的检测与安装。
 * 返回 true 表示模型已就绪，可以继续走 start-capture 流程。
 */
async function ensureSpeechModelReady(bcpLang) {
  if (!SpeechRecognitionAPI) {
    statusDiv.textContent = '❌ 当前浏览器不支持 SpeechRecognition API（需要较新版本的 Edge/Chrome）';
    return false;
  }

  // 部分浏览器没有 available()，直接放行
  if (typeof SpeechRecognitionAPI.available !== 'function') {
    return true;
  }

  let availability;
  try {
    availability = await SpeechRecognitionAPI.available({ langs: [bcpLang], processLocally: true });
    console.log(`[Popup] 离线模型可用性 ${bcpLang}: ${availability}`);
  } catch (e) {
    statusDiv.textContent = `❌ 检测模型可用性失败: ${e.message}`;
    return false;
  }

  if (availability === 'available') return true;

  if (availability === 'downloadable' || availability === 'downloading') {
    if (typeof SpeechRecognitionAPI.install !== 'function') {
      statusDiv.textContent = `❌ 语言 ${bcpLang} 需要下载离线模型，但当前浏览器不支持 install()`;
      return false;
    }
    statusDiv.textContent = `⏳ 正在下载 ${bcpLang} 离线语音模型，首次使用需要等待，请勿关闭弹窗...`;
    try {
      const installed = await SpeechRecognitionAPI.install({ langs: [bcpLang], processLocally: true });
      if (!installed) {
        statusDiv.textContent = `❌ 离线模型（${bcpLang}）安装失败`;
        return false;
      }
      return true;
    } catch (e) {
      statusDiv.textContent = `❌ 离线模型安装出错: ${e.message}`;
      return false;
    }
  }

  // 'unavailable' 等：设备/浏览器不支持该语言的离线模型
  statusDiv.textContent = `❌ 当前设备不支持语言 ${bcpLang} 的离线语音识别模型`;
  return false;
}

// ════════════════════════════════════════════════════════════
// 【新增】语言模型清单：探测每种候选语言的离线模型状态，
// 支持用户提前下载，不必等到点 Start 才发现要等下载。
// ════════════════════════════════════════════════════════════
// 【说明】SpeechRecognition API 没有“列出所有支持语言”的接口，只能对
// 具体语言逐个调用 available({langs:[xxx], quality:'conversation'}) 探测。
// 这份候选清单是产品原本想覆盖的语言范围，不代表任何一个浏览器一定支持——
// Chrome 和 Edge 的语言表本来就不一样，实际状态以每一行探测出的结果为准。
const CANDIDATE_LANGS = [
  { code: 'en', label: 'English' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'fr', label: 'Français' },
  { code: 'de', label: 'Deutsch' },
  { code: 'ru', label: 'Русский' },
  { code: 'es', label: 'Español' },
  { code: 'zh', label: '中文' },
];

// 容器由 popup.html 提供，id="model-list"；没有这个容器时静默跳过整个功能，
// 不影响原有 Start/Stop 流程。
const modelListEl     = document.getElementById('model-list');
const refreshModelsBtn = document.getElementById('refreshModelsBtn');

// 记录正在安装的语言，避免重复点击同一个下载按钮触发多次 install()
const installingLangs = new Set();

function statusBadge(state) {
  switch (state) {
    case 'available':    return { text: '✅ 已就绪', cls: 'ok' };
    case 'downloadable': return { text: '⬇️ 可下载', cls: 'todo' };
    case 'downloading':  return { text: '⏳ 下载中', cls: 'busy' };
    case 'unavailable':  return { text: '❌ 不支持', cls: 'no' };
    case 'checking':     return { text: '检测中...', cls: 'busy' };
    default:              return { text: state || '未知', cls: 'no' };
  }
}

async function checkLangAvailability(bcpLang) {
  if (!SpeechRecognitionAPI || typeof SpeechRecognitionAPI.available !== 'function') {
    return 'unavailable';
  }
  try {
    return await SpeechRecognitionAPI.available({ langs: [bcpLang], processLocally: true });
  } catch (e) {
    console.warn(`[Popup] 检测 ${bcpLang} 可用性失败:`, e.message);
    return 'unavailable';
  }
}

function renderModelRow(lang, state) {
  const bcpLang = toBcp47(lang.code);

  const row = document.createElement('div');
  row.className = 'model-row';
  row.dataset.lang = lang.code;

  const nameEl = document.createElement('span');
  nameEl.className = 'model-row-name';
  nameEl.textContent = lang.label;
  row.appendChild(nameEl);

  const badge = statusBadge(state);
  const statusEl = document.createElement('span');
  statusEl.className = `model-row-status ${badge.cls}`;
  statusEl.textContent = badge.text;
  row.appendChild(statusEl);

  if (state === 'downloadable') {
    const btn = document.createElement('button');
    btn.className = 'model-row-download-btn';
    btn.textContent = '下载';
    // 【关键】这是按钮自身的 click 回调，天然带有用户手势，
    // 可以安全地在这里直接调用 install()，不会被浏览器拒绝。
    btn.onclick = async (e) => {
      e.stopPropagation();
      if (installingLangs.has(lang.code)) return;
      installingLangs.add(lang.code);
      btn.disabled = true;
      statusEl.textContent = statusBadge('downloading').text;
      statusEl.className = `model-row-status ${statusBadge('downloading').cls}`;
      try {
        const ok = await SpeechRecognitionAPI.install({ langs: [bcpLang], processLocally: true });
        if (ok) {
          statusEl.textContent = statusBadge('available').text;
          statusEl.className = `model-row-status ${statusBadge('available').cls}`;
          btn.remove();
        } else {
          statusEl.textContent = '❌ 下载失败';
          statusEl.className = 'model-row-status no';
          btn.disabled = false;
        }
      } catch (err) {
        console.error(`[Popup] ${lang.code} 模型下载失败:`, err);
        statusEl.textContent = `❌ ${err.message}`;
        statusEl.className = 'model-row-status no';
        btn.disabled = false;
      } finally {
        installingLangs.delete(lang.code);
      }
    };
    row.appendChild(btn);
  }

  return row;
}

async function renderModelList() {
  if (!modelListEl) return; // popup.html 未提供容器时，功能整体跳过

  if (!SpeechRecognitionAPI) {
    modelListEl.textContent = '当前浏览器不支持 SpeechRecognition 离线语音识别（建议使用较新版本的 Edge/Chrome）';
    return;
  }

  modelListEl.innerHTML = '';

  // 先渲染“检测中”占位行，避免弹窗打开瞬间是空白的
  const rowRefs = new Map();
  for (const lang of CANDIDATE_LANGS) {
    const row = renderModelRow(lang, 'checking');
    rowRefs.set(lang.code, row);
    modelListEl.appendChild(row);
  }

  // 并发探测所有候选语言，每个探测完成后立刻替换对应行，
  // 不用等全部语言都测完才显示结果。
  CANDIDATE_LANGS.forEach(async (lang) => {
    const bcpLang = toBcp47(lang.code);
    const state = await checkLangAvailability(bcpLang);
    const newRow = renderModelRow(lang, state);
    const oldRow = rowRefs.get(lang.code);
    if (oldRow && oldRow.parentElement) {
      oldRow.replaceWith(newRow);
    }
    rowRefs.set(lang.code, newRow);
  });
}

if (refreshModelsBtn) {
  refreshModelsBtn.onclick = () => renderModelList();
}
document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  const restrictedProtocols = ['chrome:', 'edge:', 'about:', 'view-source:'];
  const restrictedHosts     = ['chromewebstore.google.com', 'chrome.google.com'];

  let isRestricted = restrictedProtocols.some(p => tab.url.startsWith(p)) ||
                     restrictedHosts.some(h => tab.url.includes(h));

  if (tab.url.startsWith('chrome-extension://')) isRestricted = false;

  if (isRestricted) {
    lockUIForRestrictedPage();
  } else {
    syncStatusWithBackground();
  }

  // 【新增】弹窗一打开就渲染语言模型清单，方便用户提前下载
  renderModelList();
});

function lockUIForRestrictedPage() {
  isRunning               = false;
  startBtn.disabled       = true;
  stopBtn.disabled        = true;
  langSelect.disabled     = true;
  startBtn.style.opacity  = '0.5';
  startBtn.style.cursor   = 'not-allowed';
  statusDiv.textContent   = '⚠️ 无法在此页面使用';
  statusDiv.style.color   = '#888';
}

// ── 状态同步 ──────────────────────────────────────────────────
function syncStatusWithBackground() {
  chrome.runtime.sendMessage({ type: 'get-status' }, (response) => {
    if (chrome.runtime.lastError) {
      console.warn("[Popup] get-status 失败，100ms 后重试:", chrome.runtime.lastError.message);
      setTimeout(syncStatusWithBackground, 100);
      return;
    }
    if (response && response.isCapturing) {
      if (response.currentLanguage !== undefined) {
        langSelect.value = (response.currentLanguage === null) ? 'auto' : response.currentLanguage;
      }
      updateUI(true);
      statusDiv.textContent = '✅ 实时字幕运行中';
    } else {
      updateUI(false);
      statusDiv.textContent = '待机中';
    }
  });
}

function updateUI(running) {
  isRunning               = running;
  startBtn.disabled       = running;
  stopBtn.disabled        = !running;
  langSelect.disabled     = running;
  startBtn.style.opacity  = running ? '0.5' : '1';
  startBtn.style.cursor   = running ? 'not-allowed' : 'pointer';
  statusDiv.style.color   = '';
}

// ════════════════════════════════════════════════════════════
// 启动按钮
// ════════════════════════════════════════════════════════════
startBtn.onclick = async () => {
  if (isRunning) return;

  const lang = langSelect.value === 'auto' ? null : langSelect.value;

  // 【新增】离线语音模型检测/下载必须最先做，且要紧跟本次点击手势，
  // 中间不能先去发 chrome.runtime.sendMessage 或做别的异步操作，
  // 否则 install() 会报 "Requires handling a user gesture" 错误。
  // lang === null（auto）时 SpeechRecognition 无法自动检测语种，
  // 交给 offscreen 用默认语言兜底处理，这里跳过检测。
  if (lang !== null) {
    statusDiv.textContent = '正在检查离线语音模型...';
    const bcpLang = toBcp47(lang);
    const modelReady = await ensureSpeechModelReady(bcpLang);
    if (!modelReady) return; // ensureSpeechModelReady 已经写好错误提示
  }

  statusDiv.textContent = '启动中... 请稍等';

  // 【加回】这是原始文件里就有的逻辑——Translator API 检测/预热，翻译
  // 改回浏览器内置 Translator API 之后这一步重新变得有意义。
  // lang === 'zh' 时源语言等于目标语言，翻译没有意义，跳过；
  // lang === null（auto）时没有确定的源语言可以预热，也跳过，
  // 交给 offscreen.js 那边运行时检测到实际语言后按需创建。
  if (lang !== null && lang !== 'zh') {
    const sourceLang = lang;
    const tgtLang    = 'zh';

    if (!('Translator' in self)) {
      statusDiv.textContent = '⚠️ 当前 Chrome 不支持 Translator API';
      return;
    }

    try {
      let availability;
      try {
        availability = await Translator.availability({ sourceLanguage: sourceLang, targetLanguage: tgtLang });
      } catch (e) {
        try { availability = await Translator.availability({ targetLanguage: tgtLang }); }
        catch (e2) { availability = await Translator.availability(); }
      }

      if (availability === 'unavailable') {
        statusDiv.textContent = '⚠️ 翻译模型不可用，仅显示原文';
      } else if (availability === 'downloading' || availability === 'downloadable') {
        statusDiv.textContent = '⏳ 翻译模型下载中，请稍候...';
        await new Promise(r => setTimeout(r, 5000));
      }

      try {
        await Translator.create({ sourceLanguage: sourceLang, targetLanguage: tgtLang });
      } catch (err) {
        console.warn("[Popup] Translator.create 预热失败（可忽略）:", err.message);
      }
    } catch (err) {
      console.warn("[Popup] 翻译模型检查失败:", err.message);
    }
  }

  chrome.runtime.sendMessage({ type: 'start-capture', language: lang }, (res) => {
    if (chrome.runtime.lastError) {
      statusDiv.textContent = '启动失败：' + chrome.runtime.lastError.message;
      return;
    }
    if (res?.success) {
      updateUI(true);
      statusDiv.textContent = '✅ 实时字幕运行中（模型加载中，请稍候）';
    } else {
      statusDiv.textContent = '启动失败：' + (res?.error || '未知错误');
    }
  });
};

// ════════════════════════════════════════════════════════════
// 停止按钮
// ════════════════════════════════════════════════════════════
stopBtn.onclick = () => {
  chrome.runtime.sendMessage({ type: 'stop-capture' }, (res) => {
    if (chrome.runtime.lastError) {
      console.warn("[Popup] stop-capture 响应失败:", chrome.runtime.lastError.message);
      updateUI(false);
      statusDiv.textContent = '已停止';
      return;
    }
    if (res?.success) {
      updateUI(false);
      statusDiv.textContent = '已停止';
    }
  });
};

// ════════════════════════════════════════════════════════════
// 监听来自 background 的状态推送
// ════════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'capture-stopped') {
    updateUI(false);
    statusDiv.textContent = '已停止';
  }

  // 【新增】监听模型加载失败（如 WebGPU 不支持、显存不足等）
  if (msg.type === 'capture-error') {
    updateUI(false);
    const errText = msg.error || '未知错误';
    // WebGPU 相关错误给出更友好的提示
    if (errText.includes('WebGPU') || errText.includes('adapter') || errText.includes('GPU')) {
      statusDiv.textContent = '❌ GPU 不支持：' + errText;
    } else {
      statusDiv.textContent = '❌ 模型加载失败：' + errText;
    }
    statusDiv.style.color = '#e74c3c';
  }
});