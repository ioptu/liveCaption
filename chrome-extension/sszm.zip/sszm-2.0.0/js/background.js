// js/background.js
console.log("[Background] Service Worker 启动");

let currentTabId     = null;
let offscreenPort    = null;
let isCapturing      = false;
let currentLanguage  = null;
let subtitleWindowId = null;

// ════════════════════════════════════════════════════════════
// Offscreen 管理（心跳保活方案）
// ════════════════════════════════════════════════════════════
async function ensureOffscreen() {
  try {
    const has = await chrome.offscreen.hasDocument();
    if (has) return;
  } catch (e) {}
  try {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (contexts.length > 0) return;
  } catch (e) {}

  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Capture tab audio for Voxtral transcription'
  });
  console.log("[Background] Offscreen 文档已创建");
}

// ── Port 连接监听 ─────────────────────────────────────────────
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'offscreen') return;

  offscreenPort = port;
  console.log("[Background] Offscreen Port 已连接");

  port.onMessage.addListener((msg) => {
    if (msg.type === 'heartbeat') return;

    if (msg.type !== 'subtitle-result') return;

    // 转发给 content.js
    if (currentTabId) {
      // 【诊断】译文补丁消息（tisbreak=true 且带 pairId）单独打日志，
      // 之前 .catch(()=>{}) 是静默吞掉的，任何转发失败都完全看不出来。
      const isTranslationPatch = msg.tisbreak && msg.pairId != null;
      /*if (isTranslationPatch) {
        console.log(`[诊断][background.js] 转发译文补丁 pairId=${msg.pairId} 给 content.js，目标 tabId=${currentTabId}`);
      }*/
      chrome.tabs.sendMessage(currentTabId, {
        type: 'subtitle-update',
        text: msg.text || '',
        translatedText: msg.translatedText || '',
        status: msg.status,
        isbreak: msg.isbreak,
        tisbreak: msg.tisbreak,
        pairId: msg.pairId
      }).catch((err) => {
        /*if (isTranslationPatch) {
          console.error(`[诊断][background.js] 转发译文补丁 pairId=${msg.pairId} 失败:`, err?.message);
        }*/
      });
    }

    // 转发给 window_subtitle.js
    chrome.runtime.sendMessage({
      type: 'window-subtitle-update',
      text: msg.text || '',
      translatedText: msg.translatedText || '',
      status: msg.status,
      isbreak: msg.isbreak,
      tisbreak: msg.tisbreak,
      pairId: msg.pairId
    }).catch((err) => {
      /*if (msg.tisbreak && msg.pairId != null) {
        console.error(`[诊断][background.js] 转发译文补丁 pairId=${msg.pairId} 给 window_subtitle.js 失败:`, err?.message);
      }*/
    });

    // 【新增】转发模型加载错误给 popup，显示友好提示
    if (msg.status === 'error') {
      chrome.runtime.sendMessage({
        type: 'capture-error',
        error: msg.error || '未知错误'
      }).catch(() => {});
      isCapturing = false;
    }

    if (msg.status === 'stopped' && isCapturing) {
      isCapturing = false;
    }
  });

  port.onDisconnect.addListener(() => {
    console.log("[Background] Offscreen Port 断开");
    offscreenPort = null;
  });
});

// ── 停止清理 ──────────────────────────────────────────────────
// 【修复】改为 async，await closeOffscreenDocument，
// 确保 offscreen 完全关闭后再重置状态，避免状态不一致。
async function forceStopAll() {
  console.log("[Background] 执行全局停止清理逻辑");

  if (offscreenPort) {
    try { offscreenPort.postMessage({ type: 'close-recording' }); } catch (_) {}
  }

  if (currentTabId) {
    chrome.tabs.sendMessage(currentTabId, {
      type: 'subtitle-update',
      text: '',
      status: 'stopped'
    }).catch(() => {});
  }

  // 【修复】await 确保 offscreen 关闭完成后再重置状态
  await closeOffscreenDocument();

  isCapturing      = false;
  currentTabId     = null;
  subtitleWindowId = null;

  chrome.runtime.sendMessage({ type: 'capture-stopped' }).catch(() => {});
}

// ── 消息处理 ──────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.type === 'get-status') {
    sendResponse({ isCapturing, currentLanguage });
    return true;
  }

  if (msg.type === 'detect-language') {
    chrome.i18n.detectLanguage(msg.text, (result) => {
      sendResponse(result);
    });
    return true;
  }

  if (msg.type === 'start-capture') {
    currentLanguage = msg.language;
    const lang = msg.language === 'auto' ? null : msg.language;

    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) throw new Error("无法获取当前活跃标签页");
        currentTabId = tab.id;

        if (tab.url.startsWith('chrome-extension://')) {
          try {
            const win = await chrome.windows.create({
              url: 'subtitle_window.html',
              type: 'popup',
              width: 900,
              height: 250,
              top: 700
            });
            subtitleWindowId = win.id;
          } catch (e) {
            console.error("创建独立窗口失败", e);
          }
        }

        const streamId = await new Promise((resolve, reject) => {
          chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id }, (id) => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(id);
          });
        });

        await ensureOffscreen();

        let waitCount = 0;
        while (!offscreenPort && waitCount < 30) {
          await new Promise(r => setTimeout(r, 200));
          waitCount++;
        }
        if (!offscreenPort) throw new Error("Offscreen Port 连接超时");

        offscreenPort.postMessage({ type: 'start-recording', data: streamId, language: lang });

        isCapturing = true;
        sendResponse({ success: true });
      } catch (err) {
        isCapturing = false;
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (msg.type === 'stop-capture') {
    if (subtitleWindowId) {
      chrome.windows.remove(subtitleWindowId).catch(() => {});
    }
    // 【修复】forceStopAll 现在是 async，但 onMessage 回调不需要等待它完成
    // 先立即 sendResponse，再异步执行清理，避免 message channel 超时
    forceStopAll().catch(e => console.warn("[Background] forceStopAll 出错:", e));
    sendResponse({ success: true });
    return true;
  }
});

// ── 窗口/标签页关闭监听 ───────────────────────────────────────
chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === subtitleWindowId) {
    console.log("[Background] 字幕独立窗口被关闭");
    subtitleWindowId = null;
    forceStopAll().catch(e => console.warn("[Background] forceStopAll 出错:", e));
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === currentTabId) {
    if (subtitleWindowId) {
      chrome.windows.remove(subtitleWindowId).catch(() => {});
    }
    forceStopAll().catch(e => console.warn("[Background] forceStopAll 出错:", e));
  }
});

async function closeOffscreenDocument() {
  try {
    const has = await chrome.offscreen.hasDocument();
    if (has) await chrome.offscreen.closeDocument();
  } catch (e) {
    console.warn("[Background] closeOffscreenDocument 失败:", e.message);
  }
}