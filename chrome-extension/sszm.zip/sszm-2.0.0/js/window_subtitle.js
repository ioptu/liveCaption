// js/window_subtitle.js

let subtitlePanel = document.getElementById('sszm-subtitle-panel');
let scrollBtn = document.getElementById('sszm-scroll-bottom-btn'); // 【改动】现在身兼两职：回到底部 + 开启画中画
const subtitleContainer = document.getElementById('sszm-subtitle-container');

// ════════════════════════════════════════════════════════════
// 【新增】Document Picture-in-Picture：把字幕容器搬进一个系统级
// “始终置顶”的浮动窗口，替代原来“只是普通弹窗”的体验。
//
// 两条硬性限制（浏览器规范定死的，绕不开）：
//   1. requestWindow() 必须在真实用户手势里调用，不能自动触发，
//      所以这里挂在按钮的 click 事件上，不能在页面加载时自动执行。
//   2. PiP 窗口“永远不会比打开它的这个窗口活得更久”——这个 window_subtitle
//      页面本身必须一直开着，PiP 窗口才能存在。所以不能真正关掉这个
//      父窗口，只能把它最小化收起来，PiP 关闭时再恢复。
//
// 【改动】“开启画中画”按钮和“回到底部”按钮合并成同一个按钮元素，
// 点击面积更大。两者互斥展示，同一时刻只显示其中一个：
//   - 有内容需要滚动到底部时 → 显示“回到底部”（优先级更高）
//   - 不需要滚动、且画中画还没开启时 → 显示“开启画中画”
//   - 不需要滚动、且画中画已经开启 → 什么都不显示（跟原来滚动按钮在
//     不需要时隐藏的逻辑一致）
// ════════════════════════════════════════════════════════════
let pipWindow = null;
let pipActive = false;
let needsScrollDown = false; // 当前是否处于“需要点一下才能回到底部”的状态

function updateActionButton() {
    if (needsScrollDown) {
        scrollBtn.textContent = '↓ 回到底部';
        scrollBtn.dataset.mode = 'scroll';
        scrollBtn.classList.add('show');
    } else if (!pipActive) {
        scrollBtn.textContent = '📌 开启画中画字幕';
        scrollBtn.dataset.mode = 'pip';
        scrollBtn.classList.add('show');
    } else {
        scrollBtn.dataset.mode = '';
        scrollBtn.classList.remove('show');
    }
}

function copyStylesInto(targetDoc) {
    // PiP 窗口是一个全新的空白同源文档，不会自动带上任何 CSS，
    // 需要把 <link>/<style> 挨个搬一份过去。用 cloneNode 而不是读取
    // cssRules，避免某些情况下跨域样式表读取报错的问题。
    document.querySelectorAll('link[rel="stylesheet"], style').forEach((node) => {
        targetDoc.head.appendChild(node.cloneNode(true));
    });
}

async function togglePictureInPicture() {
    if (!('documentPictureInPicture' in window)) {
        alert('当前浏览器不支持画中画（Document Picture-in-Picture 需要 Chrome 116+）');
        return;
    }

    scrollBtn.disabled = true;
    try {
        pipWindow = await window.documentPictureInPicture.requestWindow({
            width: 900,
            height: 220,
        });
    } catch (err) {
        console.error('[Window] 开启画中画失败:', err.message);
        scrollBtn.disabled = false;
        return;
    }

    copyStylesInto(pipWindow.document);
    pipWindow.document.body.style.margin = '0';
    pipWindow.document.body.style.backgroundColor = '#000';

    // 【关键】不是复制，是把 DOM 节点整个“搬家”过去——subtitleContainer
    // 里所有子元素（subtitlePanel、scrollBtn 等）JS 里原来的变量引用
    // 依然指向同一批节点对象，搬家不影响后续 renderFrame() 继续正常操作它们。
    pipWindow.document.body.appendChild(subtitleContainer);

    scrollBtn.disabled = false;
    pipActive = true;
    updateActionButton(); // 画中画已开启，按钮切回“回到底部”角色（如果需要的话），否则隐藏

    // 尽量把这个父窗口收起来，不占屏幕——用户看到的实际内容都在 PiP 窗口里了。
    try {
        const win = await chrome.windows.getCurrent();
        chrome.windows.update(win.id, { state: 'minimized' }).catch(() => {});
    } catch (_) { /* 拿不到也无所谓，不影响 PiP 本身 */ }

    // PiP 窗口被用户关闭（点了 PiP 窗口自带的关闭按钮，或切回原标签页）时，
    // 把字幕容器搬回父窗口，父窗口恢复正常大小，方便下次重新点击开启。
    pipWindow.addEventListener('pagehide', () => {
        document.body.appendChild(subtitleContainer);
        pipWindow = null;
        pipActive = false;
        updateActionButton();
        chrome.windows.getCurrent().then((win) => {
            chrome.windows.update(win.id, { state: 'normal' }).catch(() => {});
        }).catch(() => {});
    });
}

// 滚动状态检测（不再需要分割线拖拽逻辑，单栏没有可拖的边界）
let scrollTimeout;
const updateScrollButton = () => {
    if (scrollTimeout) return;
    scrollTimeout = setTimeout(() => {
        const dist = subtitlePanel.scrollHeight - subtitlePanel.scrollTop - subtitlePanel.clientHeight;
        needsScrollDown = dist > 50;
        updateActionButton();
        scrollTimeout = null;
    }, 150);
};

subtitlePanel.addEventListener('scroll', updateScrollButton);

scrollBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    if (scrollBtn.dataset.mode === 'scroll') {
        subtitlePanel.scrollTo({ top: subtitlePanel.scrollHeight, behavior: 'smooth' });
        // 滚动到底部之后，下一次 scroll 事件会自然把 needsScrollDown
        // 重新判断为 false，按钮到时候会自己切回“开启画中画”角色（如果还没开启的话）
    } else if (scrollBtn.dataset.mode === 'pip') {
        togglePictureInPicture();
    }
});

// 页面刚加载时没有任何 scroll 事件触发过，手动跑一次，确保初始状态
// 正确显示“开启画中画”（而不是因为没跑过 updateActionButton 而一直隐藏）。
updateActionButton();



// 接收并渲染字幕数据逻辑
let pendingFinals = [];
let pendingInterim = null;
let isAnimationFrameActive = false;

// ── 单栏“原文+译文”成对显示（和 content.js 保持一致，逻辑同步）───
const HISTORY_COLORS = ['#E6DC84']; // [最新, 倒数第二, 最旧]
const COLOR_WINDOW = HISTORY_COLORS.length;

// 历史保留量按“段数”控制，默认 5 段，改成 Infinity 即可不限制。
let PAIR_CAP = 10;

const CURRENT_PAIR_CLASS = 'sszm-current-pair';
const CURRENT_PAIR_COLOR = '#ffeb3b';

function createPairElement(className) {
    const pair = document.createElement('div');
    pair.className = className;
    const orig = document.createElement('div');
    orig.className = 'sszm-pair-original';
    const trans = document.createElement('div');
    trans.className = 'sszm-pair-translation';
    pair.appendChild(orig);
    pair.appendChild(trans);
    return pair;
}

function ensureCurrentPair(container) {
    let cur = container.querySelector(`:scope > .${CURRENT_PAIR_CLASS}`);
    if (!cur) {
        cur = createPairElement(CURRENT_PAIR_CLASS);
        cur.style.color = CURRENT_PAIR_COLOR;
        cur.style.fontWeight = '500';
        container.appendChild(cur);
    } else if (cur !== container.lastElementChild) {
        container.appendChild(cur);
    }
    return cur;
}

function updateCurrentPair(container, text, translatedText) {
    if (!container) return;
    const cur = ensureCurrentPair(container);
    cur.firstElementChild.textContent = text || '';
    cur.lastElementChild.textContent  = translatedText || '';
}

// 【改动】译文可能还没翻译好，pairId 打在 data 属性上，供
// updatePairTranslation() 后续找到这一段补上译文。
// 【性能】上色和裁剪都不遍历全部历史，开销恒定，详细说明见 content.js 同名函数。
function finalizePairIntoHistory(container, text, translatedText, pairId) {
    if (!container || !text) return;
    const cur = ensureCurrentPair(container);

    const pair = createPairElement('sszm-pair');
    pair.firstElementChild.textContent = text;
    pair.lastElementChild.textContent  = translatedText || '';
    if (pairId != null) pair.dataset.pairId = String(pairId);
    container.insertBefore(pair, cur);

    cur.firstElementChild.textContent = '';
    cur.lastElementChild.textContent  = '';

    let node = pair;
    for (let i = 0; i < COLOR_WINDOW && node; i++) {
        node.style.color = HISTORY_COLORS[i];
        node = node.previousElementSibling;
    }
    if (node) node.style.color = '';

    while (container.childElementCount - 1 > PAIR_CAP) {
        const oldest = container.firstElementChild;
        if (!oldest || oldest === cur) break;
        container.removeChild(oldest);
    }
}

// 【新增】译文翻译完之后单独补发的更新，详细说明见 content.js 同名函数。
function updatePairTranslation(container, pairId, translatedText) {
    if (!container || pairId == null) return;
    const pair = container.querySelector(`:scope > .sszm-pair[data-pair-id="${pairId}"]`);
    //console.log(`[诊断][window_subtitle.js] 收到 pairId=${pairId} 的译文补丁，${pair ? '找到对应段落，已更新' : '没找到对应段落（可能已被裁剪掉）'}`);
    if (!pair) return;
    pair.lastElementChild.textContent = translatedText || '';
}

function renderFrame() {
    if (!subtitlePanel) {
        isAnimationFrameActive = false;
        if (pendingFinals.length > 0 || pendingInterim) {
            isAnimationFrameActive = true;
            requestAnimationFrame(renderFrame);
        }
        return;
    }

    // 先处理这一批全部排队的定稿/译文补丁消息，一条都不跳过
    while (pendingFinals.length > 0) {
        const data = pendingFinals.shift();
        const { text, translatedText, isbreak, tisbreak, pairId } = data;
        if (isbreak && text?.trim()) {
            finalizePairIntoHistory(subtitlePanel, text, translatedText, pairId);
        } else if (tisbreak && pairId != null) {
            updatePairTranslation(subtitlePanel, pairId, translatedText);
        }
    }

    // 未定稿只需要渲染最新的一条，中间态可以丢
    if (pendingInterim) {
        const { text, translatedText } = pendingInterim;
        updateCurrentPair(subtitlePanel, text, translatedText);
        pendingInterim = null;
    }

    // 【改动】不能再用 scrollBtn.classList.contains('show') 判断了——
    // 这个 class 现在也会因为“要显示开启画中画按钮”而存在，用它判断
    // 会导致画中画按钮显示期间被误判成“用户正在往上翻，不要自动滚动”。
    // 改用专门的 needsScrollDown 状态变量，只在真的需要“回到底部”时才
    // 暂停自动滚动。
    if (!needsScrollDown) {
        subtitlePanel.scrollTop = subtitlePanel.scrollHeight;
    }

    isAnimationFrameActive = false;
}

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'window-subtitle-update') {
        // 【改动】定稿/译文补丁消息进队列排队，一条都不能丢；
        // 未定稿消息只保留最新一条，覆盖旧的就行。跟 content.js 同一个
        // 问题的同一套修复：原来单槽位 pendingData 会被后到的消息覆盖，
        // 导致同一动画帧内到达的多条消息里，前面的凭空消失。
        if (msg.isbreak || msg.tisbreak) {
            pendingFinals.push(msg);
        } else {
            pendingInterim = msg;
        }
        if (!isAnimationFrameActive) {
            isAnimationFrameActive = true;
            requestAnimationFrame(renderFrame);
        }
    }
});