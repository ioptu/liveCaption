// js/recorder.js
// 【替换说明】原实现通过 AudioWorklet 把 tabCapture 的音频转成 PCM Float32 帧，
// 喂给 Voxtral ONNX 做流式推理。改用 SpeechRecognition（SODA）后，识别引擎
// 直接消费 MediaStreamTrack（recognition.start(track)），不再需要手动抽帧，
// 因此这里砍掉了 AudioWorklet 相关逻辑，只保留：
//   1) tabCapture → getUserMedia 拿到音频流
//   2) 把流重新接回扬声器（tabCapture 会静音原始标签页，不接回用户就听不到声音）
//   3) 把音频轨道（MediaStreamTrack）交还给调用方
export class Recorder {
  static instance = null;
  static getInstance() {
    if (!Recorder.instance) Recorder.instance = new Recorder();
    return Recorder.instance;
  }

  constructor() {
    this.stream       = null;
    this.audioContext = null;
    this.source       = null;
  }

  /**
   * 开始采集 tab 音频，返回可直接传给 recognition.start(track) 的 MediaStreamTrack。
   */
  async startCapture(streamId) {
    if (this.stream) {
      console.log("[Recorder] 音频流已存在，跳过重复启动");
      return this.stream.getAudioTracks()[0];
    }

    console.log("[Recorder] 开始获取 tab 音频流，streamId:", streamId);

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          mandatory: {
            chromeMediaSource: 'tab',
            chromeMediaSourceId: streamId
          }
        }
      });
      console.log("[Recorder] getUserMedia 成功");

      // 【保留回放】tabCapture 会静音原始标签页的输出，必须手动把流接回扬声器，
      // 否则用户在开启字幕后会听不到视频/音频本身的声音。
      this.audioContext = new AudioContext();
      this.source = this.audioContext.createMediaStreamSource(this.stream);
      this.source.connect(this.audioContext.destination);

      const [track] = this.stream.getAudioTracks();
      if (!track) {
        throw new Error("未能从采集流中获取到音频轨道");
      }
      console.log("[Recorder] 音频轨道就绪，交由 SpeechRecognition 使用");
      return track;
    } catch (err) {
      console.error("[Recorder] 启动失败:", err);
      this._cleanup();
      throw err;
    }
  }

  stopCapture() {
    console.log("[Recorder] 停止采集");
    this.stream?.getTracks().forEach(track => track.stop());
    this.source?.disconnect();
    this._cleanup();
  }

  _cleanup() {
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(e => {
        console.warn("[Recorder] AudioContext close 失败:", e);
      });
    }
    this.stream       = null;
    this.source       = null;
    this.audioContext = null;
  }
}