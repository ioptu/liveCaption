// js/offscreen.js

// 屏蔽普通日志
console.log = function() {};

import { Recorder } from '../js/recorder.js';
import * as OpenCC from '../js/opencce.js';
// 【改回】翻译从本地 HY-MT1.5-1.8B-ONNX 换回浏览器内置 Translator API。
// 不再需要 transformers.js/onnxruntime-web 的本地打包文件和相关 env 配置
// （wasmPaths/numThreads/allowLocalModels/remoteHost/proxy 这些都是给
// transformers.js 用的，Translator API 是浏览器原生对象，不需要这些）。

// ════════════════════════════════════════════════════════════
// 【替换说明】原实现在这里加载 Voxtral-Mini-4B-Realtime ONNX 模型
// （WebGPU + transformers.js），做流式音频编码+解码生成字幕。
// 现在改为使用浏览器内置的 SpeechRecognition API（Chrome/Edge 142+
// 支持 processLocally 离线模式，即 SODA）。
//
// ⚠️ 语言支持范围因浏览器而异：Chrome 和 Edge 各自维护自己的模型语言表，
// 不是同一份数据（这是个跨浏览器扩展，两边都能装）。之前以为 SODA 不支持
// 中文/日文是只查了 Edge 官方文档得出的误判——Chrome 官方规范 explainer
// 里明确列了 zh-CN/zh-TW/ja-JP 等更大范围的语言。实际支持情况一律以
// ensureModelReady() 里的 available() 探测结果为准，不要在代码里硬编码
// 某个浏览器的语言表。
//
// 另外有个曾经踩过的坑：available()/install() 有 quality 参数
// （command/dictation/conversation 三档），实测证明传 conversation 会让
// 所有语言都变 unavailable（这个档位当前浏览器版本大概率还没铺开），
// 已经撤回，判定统一用默认档位。
//
// 【新增】源语言不再完全信任用户下拉框选的那个值。识别引擎在某些情况下
// 会不按你指定的 recognition.lang 解码（比如指定英文但实际说的是中文，
// 引擎自己纠正过来了），JS API 没有暴露“这次结果实际是哪个语言”这个信息，
// 所以改用浏览器的 LanguageDetector（内置 AI 语言检测）对每次定稿文本
// 单独判断实际语言，再拿这个判断结果去决定翻译器的 sourceLanguage，
// 而不是死认用户选的那个语言。详见下方 detectActualSourceLang()。
// ════════════════════════════════════════════════════════════

const converter = OpenCC.Converter({ from: 'tw', to: 'cn' });
const recorder = Recorder.getInstance();

// ════════════════════════════════════════════════════════════
// Port：直接建立，无需重连逻辑（心跳保活方案）
// ════════════════════════════════════════════════════════════
const port = chrome.runtime.connect({ name: 'offscreen' });

port.onMessage.addListener((msg) => {
  if (msg.type === 'start-recording') {
    console.log("[Offscreen] 收到启动录制命令");
    handleStartRecording(msg);
  }
  if (msg.type === 'stop-recording' || msg.type === 'close-recording') {
    console.log("[Offscreen] 收到停止命令");
    handleStopRecording();
  }
});

// ── 心跳保活 ──────────────────────────────────────────────────
const HEARTBEAT_INTERVAL_MS = 15000;
let heartbeatTimer = null;

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    try {
      port.postMessage({ type: 'heartbeat' });
    } catch (e) {
      console.warn("[Offscreen] 心跳发送失败:", e.message);
      stopHeartbeat();
    }
  }, HEARTBEAT_INTERVAL_MS);
  console.log(`[Offscreen] 心跳已启动（每${HEARTBEAT_INTERVAL_MS / 1000}秒）`);
}

function stopHeartbeat() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
    console.log("[Offscreen] 心跳已停止");
  }
}

// ── 状态变量 ──────────────────────────────────────────────────
let targetLanguage = 'zh';
let stopRequested  = false;

const SHOW_TRANSLATION_ENABLED = true;  // 改成 false 只显示原文

let recognition   = null;
let currentTrack   = null;
const readyLangs  = new Set();

// 【新增】记录本次 offscreen 会话中已确认“available() 说可用，但
// recognition.start() 实际失败”的语言。这是浏览器这个实验性 API 自身
// 的不一致行为（不是我们代码的 bug），available() 的结果不可信一次，
// 后面大概率还是不可信——记下来避免用户每次点 Start 都完整走一遍
// “检测通过 → 采集音频 → 启动失败”的流程，浪费时间也浪费一次 tabCapture。
// 这个集合只在 offscreen document 存活期间有效，重新开始采集时会重置。
const knownBrokenLangs = new Set();

// 未以句末标点结束的文本跨轮保留，避免识别引擎内部重启时字幕跳变
let crossRoundAccumulatedText = "";

const SpeechRecognitionAPI = self.SpeechRecognition || self.webkitSpeechRecognition;

// ── 简化语言代码 → BCP47 ─────────────────────────────────────
// 支持范围因浏览器而异，这里只做代码 → BCP47 的映射，不代表都支持，
// 实际以 ensureModelReady() 的 available() 探测结果为准。
const LANG_MAP = {
  en: 'en-US',
  ja: 'ja-JP',
  ko: 'ko-KR',
  fr: 'fr-FR',
  de: 'de-DE',
  ru: 'ru-RU',
  es: 'es-ES',
  zh: 'zh-CN',
};
function toBcp47(lang) {
  return LANG_MAP[lang] || lang || 'en-US';
}

// ── 离线模型可用性检测 ────────────────────────────────────────
// 【重要】install() 不能在这里调用！offscreen document 没有用户手势上下文，
// 调用会直接报 "Requires handling a user gesture" 错误。
// 模型下载已经在 popup.js 的按钮 click 回调里（ensureSpeechModelReady）
// 提前做完了，这里只需要确认一下状态。
//
// 【已排查清楚，不再是待验证假设】曾怀疑过 quality 参数、以及
// start(track) 这个重载本身有问题，两轮实测都排除了：
//   1. quality:'conversation' 在这台设备上对所有语言都返回 unavailable，
//      说明这个档位大概率还没铺开，跟我们的场景需不需要它没关系。
//   2. 不传 track、直接 recognition.start() 走系统麦克风，同样的语言
//      一样报 language-not-supported——证明问题和 start(track) 这个
//      重载无关。
// 结论：available() 对 zh-CN 报 available，但 start() 实际失败，是这个
// 实验性 API 在当前浏览器版本上的真实不一致行为，不是我们代码的问题，
// 也不是能靠调参数绕过的问题。下面用 knownBrokenLangs 记录下来，
// 避免同一个已确认打不开的语言被反复整套流程重试。
async function ensureModelReady(bcpLang) {
  if (knownBrokenLangs.has(bcpLang)) {
    port.postMessage({
      type: 'subtitle-result', status: 'error',
      error: `语言 ${bcpLang} 在本次会话中已确认无法启动识别（浏览器 available() 检测结果与实际不一致，这是当前浏览器版本的已知问题，换个语言，或等浏览器更新后重新尝试）`
    });
    return false;
  }

  if (readyLangs.has(bcpLang)) return true;

  if (!SpeechRecognitionAPI) {
    port.postMessage({
      type: 'subtitle-result', status: 'error',
      error: '当前浏览器不支持 SpeechRecognition API（需要 Chrome/Edge 内置离线语音识别，建议使用较新版本的浏览器）'
    });
    return false;
  }

  if (typeof SpeechRecognitionAPI.available !== 'function') {
    readyLangs.add(bcpLang);
    return true;
  }

  let availability;
  try {
    availability = await SpeechRecognitionAPI.available({
      langs: [bcpLang],
      processLocally: true,
    });
    console.log(`[Offscreen] 离线模型可用性 ${bcpLang}: ${availability}`);
  } catch (e) {
    port.postMessage({ type: 'subtitle-result', status: 'error', error: `检测模型可用性失败: ${e.message}` });
    return false;
  }

  if (availability === 'available') {
    readyLangs.add(bcpLang);
    return true;
  }

  if (availability === 'downloading') {
    // popup 那边的 install() 应该已经在跑了，这里只轮询等待，不重新触发下载
    port.postMessage({
      type: 'subtitle-result', status: 'update',
      text: `离线语音模型下载中，请稍候...`,
      translatedText: '', isbreak: false, tisbreak: false,
    });
    const maxWaitMs = 5 * 60 * 1000;
    const start = Date.now();
    while (Date.now() - start < maxWaitMs) {
      await new Promise(r => setTimeout(r, 1500));
      try {
        availability = await SpeechRecognitionAPI.available({ langs: [bcpLang], processLocally: true });
      } catch (_) { continue; }
      if (availability === 'available') {
        readyLangs.add(bcpLang);
        return true;
      }
      if (availability !== 'downloading') break;
    }
    port.postMessage({
      type: 'subtitle-result', status: 'error',
      error: `离线模型（${bcpLang}）下载未在预期时间内完成，请重新点击 Start`
    });
    return false;
  }

  if (availability === 'downloadable') {
    // 正常流程不该走到这——popup 点击时已经把它从 downloadable 推进到
    // downloading/available 了。走到这说明 popup 那边的 install() 没有
    // 成功触发（比如用户手势判定失败），提示用户重试而不是在这里再调一次
    // install()（会因为缺少手势而必然失败）。
    port.postMessage({
      type: 'subtitle-result', status: 'error',
      error: `离线模型（${bcpLang}）尚未开始下载，请重新点击 Start 按钮触发下载`
    });
    return false;
  }

  // 'unavailable'：这台浏览器不支持该语言的离线模型，支持范围因浏览器而异
  port.postMessage({
    type: 'subtitle-result', status: 'error',
    error: `当前浏览器不支持语言 ${bcpLang} 的离线语音识别，支持范围因浏览器而异（Chrome 和 Edge 的语言覆盖不一样）`
  });
  return false;
}

// ── 翻译：浏览器内置 Translator API ──────────────────────────
// 【改回】不再用本地 HY-MT1.5 LLM，换回 Chrome/Edge 内置的 Translator
// API（self.Translator，专用 MT 模型，不是 LLM，不需要 prompt 模板，
// 直接 t.translate(text) 就行，也不需要传完整语言名，用语言代码即可）。
// 保留了 null/'' 两种返回值的约定（'' = 源语言等于目标语言，合法不需要
// 翻译；null = 真正翻译失败），这样上面 pushResult 里"翻译失败时显示
// [翻译失败]"的逻辑不用跟着改，两套翻译引擎共用同一套上层架构。
const translatorCache = new Map();

async function prepareTranslator(sourceLang, targetLang) {
  const cacheKey = `${sourceLang}-${targetLang}`;
  if (translatorCache.has(cacheKey)) return translatorCache.get(cacheKey);
  const API = self.Translator || self.translation;
  if (!API) {
    console.error('[Offscreen] 当前浏览器不支持 Translator API');
    return null;
  }
  try {
    let t;
    if (API.create) {
      t = await API.create({ sourceLanguage: sourceLang, targetLanguage: targetLang });
    } else if (API.createTranslator) {
      t = await API.createTranslator({ sourceLanguage: sourceLang, targetLanguage: targetLang });
    } else {
      throw new Error("找不到 Translator.create()/createTranslator()");
    }
    translatorCache.set(cacheKey, t);
    return t;
  } catch (err) {
    console.error(`[Offscreen] Translator 初始化失败 (${cacheKey}):`, err);
    return null;
  }
}

async function translateText(text, sourceLang) {
  // 源语言和目标语言相同时翻译没有意义，直接短路——这是“合法留空”，
  // 用空字符串表示。跟下面“真正翻译失败”要区分开，所以失败的情况
  // 统一返回 null，调用方靠这个区分“不需要翻译”和“翻译出错了”。
  if (sourceLang === targetLanguage) return '';
  if (!text.trim()) return '';

  // 【诊断】记录这次调用的入口时间和文本长度，配合下面出口处的日志，
  // 能看出这次翻译到底有没有真正跑完、跑了多久。Translator API 是专用
  // 轻量 MT 模型，正常情况下应该比 LLM 快得多，这行日志留着方便对比。
  const __t0 = Date.now();
  const __len = text.length;
  console.log(`[诊断][translateText] 开始，长度=${__len}，内容前20字="${text.slice(0, 20)}..."`);

  const t = await prepareTranslator(sourceLang, targetLanguage);
  if (!t) {
    console.log(`[诊断][translateText] Translator 不可用，长度=${__len}`);
    return null; // 初始化失败，属于真正的失败
  }

  try {
    const result = (await t.translate(text))?.trim() || '';
    console.log(`[诊断][translateText] 结束，长度=${__len}，耗时=${Date.now() - __t0}ms，结果="${result.slice(0, 20)}..."`);
    // 模型正常跑完但没吐出任何内容，也当成失败处理，不当成“合法留空”
    return result || null;
  } catch (e) {
    console.error(`[诊断][translateText] 抛出异常，长度=${__len}，耗时=${Date.now() - __t0}ms`, e);
    return null;
  }
}

// ── 语言检测：识别结果实际是什么语言，由这里说了算 ────────────
// LanguageDetector 是 Chrome 内置 AI 的另一个模块（跟 Translator 是邻居），
// Chrome 141+ 用法是全局 window.LanguageDetector（更早版本挂在
// window.ai.languageDetector 下，这里不做兼容，太老的版本本来也用不了
// 这一整套 processLocally 的东西）。
let languageDetector = null;
let languageDetectorPromise = null;

async function ensureLanguageDetector() {
  if (languageDetector) return languageDetector;
  if (!('LanguageDetector' in self)) return null;
  if (!languageDetectorPromise) {
    // expectedInputLanguages 给检测器一个候选范围提示，能提高准确率，
    // 用我们已知会用到的这几种语言（SPEECH_LANG_MAP 的 BCP47 值）。
    languageDetectorPromise = LanguageDetector.create({
      expectedInputLanguages: Object.values(LANG_MAP),
    }).then(d => {
      languageDetector = d;
      return d;
    }).catch(e => {
      console.warn('[Offscreen] LanguageDetector 创建失败:', e.message);
      return null;
    });
  }
  return languageDetectorPromise;
}

// 官方文档明确提醒：短文本/单个词的检测准确率很低，不建议直接采信。
// 这里设一个最短字符数门槛，低于这个长度就不启用本次检测结果，
// 沿用上一次确认过的语言（lastDetectedLang）作为兜底。
const MIN_DETECT_LENGTH = 8;
const MIN_DETECT_CONFIDENCE = 0.4;
let lastDetectedLang = null; // 记住上一次检测出的语言，短文本/检测失败时的兜底

async function detectActualSourceLang(text, hintLang) {
  const fallback = lastDetectedLang || hintLang;
  if (!text || text.trim().length < MIN_DETECT_LENGTH) return fallback;

  const detector = await ensureLanguageDetector();
  if (!detector) return fallback; // 浏览器不支持 LanguageDetector，退回用户选的语言

  try {
    const results = await detector.detect(text);
    const top = results?.[0];
    // 'und' 表示模型认不出属于哪个已知语言；置信度太低时也不采信，
    // 避免一次误判把后续翻译全带偏。
    if (!top || top.detectedLanguage === 'und' || top.confidence < MIN_DETECT_CONFIDENCE) {
      return fallback;
    }
    // LanguageDetector 返回的是简化语言码（'zh'/'en'/'ja' 这种），
    // 跟 Translator 的 sourceLanguage、我们内部 CANDIDATE_LANGS 用的
    // 编码体系是一致的，不需要再做 BCP47 地区变体转换。
    lastDetectedLang = top.detectedLanguage;
    return top.detectedLanguage;
  } catch (e) {
    console.warn('[Offscreen] 语言检测失败:', e.message);
    return fallback;
  }
}

// 每次定稿分配一个递增编号，译文翻译完之后单独补发消息时，靠这个编号
// 找到对应的那一段去更新译文，而不是重新创建一段新的。
let pairSeq = 0;

// ── 上屏 + 翻译（替代原 flushDecodedText）────────────────────
async function pushResult(text, hintLang, shouldBreak, resultIndex) {
  if (!text) return;

  if (!shouldBreak) {
    // 未定稿：不涉及翻译，跟之前一样一条消息搞定，直接更新“当前行”。
    // OpenCC 简繁转换是同步的本地字典转换，不涉及网络/异步，沿用上一次
    // 确认过的语言（lastDetectedLang）判断要不要转换，不会拖慢显示。
    const processed = (lastDetectedLang === 'zh') ? converter(text) : text;
    console.log(`[诊断][pushResult] resultIndex=${resultIndex} 未定稿更新，长度=${text.length}`);
    port.postMessage({
      type: 'subtitle-result', status: 'update',
      text: processed, translatedText: '', isbreak: false, tisbreak: false,
    });
    return;
  }

  // 【改动】定稿时不再等翻译跑完才上屏。原来的做法是等语言检测+翻译
  // 都跑完，才发一条同时带原文和译文的消息——但本地 LLM 翻译可能要
  // 花不短的时间，这段等待期间，下一句的临时结果会把“当前行”覆盖掉，
  // 导致刚定稿的这句原文在屏幕上凭空消失，直到译文终于跑完才重新出现，
  // 体验很突兀。
  // 现在分成两步：原文一确定（语言检测这一步很快，不是耗时瓶颈，
  // 依然同步等一下）就立刻发消息定稿上屏；译文单独放到后面翻译真正
  // 跑完后，再补发一条“只更新译文”的消息，靠 pairId 找到已经显示
  // 出来的那一段去补上译文，不会导致原文消失。
  const pairId = ++pairSeq;
  console.log(`[诊断][pushResult] pairId=${pairId} resultIndex=${resultIndex} 开始处理，原文长度=${text.length}`);

  const actualLang = await detectActualSourceLang(text, hintLang);
  let processed = text;
  if (actualLang === 'zh') processed = converter(processed);

  port.postMessage({
    type: 'subtitle-result', status: 'update',
    text: processed, translatedText: '',
    isbreak: true, tisbreak: false,
    pairId,
  });
  console.log(`[诊断][pushResult] pairId=${pairId} resultIndex=${resultIndex} 原文已上屏`);

  crossRoundAccumulatedText = "";
  
  if (!SHOW_TRANSLATION_ENABLED) {
    console.log(`[诊断][pushResult] pairId=${pairId} resultIndex=${resultIndex} 只看原文模式，跳过翻译`);
    return;
  }
  console.log(`[诊断][pushResult] pairId=${pairId} resultIndex=${resultIndex} 即将调用 translateText`);

  const translatedText = await translateText(processed, actualLang);
  console.log(`[诊断][pushResult] pairId=${pairId} resultIndex=${resultIndex} translateText 已返回，结果类型=${translatedText === null ? 'null(失败)' : translatedText === '' ? '空字符串(不需要翻译)' : '正常字符串'}`);

  if (translatedText === '') return; // 源语言=目标语言，合法不需要翻译，静默留空，不用补发

  if (translatedText === null) {
    // 【新增】翻译真正失败了（比如原文太长撞到模型的输入长度上限），
    // 明确告诉用户，而不是让这段译文永远空着——之前的问题就是失败和
    // “合法留空”长得一模一样，用户根本分不清是“还在等”还是“没了”。
    port.postMessage({
      type: 'subtitle-result', status: 'update',
      text: '', translatedText: '[翻译失败]',
      isbreak: false, tisbreak: true,
      pairId,
    });
    console.log(`[诊断][pushResult] pairId=${pairId} resultIndex=${resultIndex} 已发送 [翻译失败] 补丁消息`);
    return;
  }

  port.postMessage({
    type: 'subtitle-result', status: 'update',
    text: '', translatedText,
    isbreak: false, tisbreak: true,
    pairId,
  });
  console.log(`[诊断][pushResult] pairId=${pairId} resultIndex=${resultIndex} 已发送译文补丁消息，译文前20字="${translatedText.slice(0, 20)}..."`);
}

// ── 核心识别（替代原 runTranscription）───────────────────────
function startRecognition(sourceLang, track) {
  recognition = new SpeechRecognitionAPI();
  recognition.lang            = toBcp47(sourceLang);
  recognition.continuous      = true;
  recognition.interimResults  = true;
  recognition.processLocally  = true;

  // 【关键】unspokenPunctuation 是刚加进 Web Speech API 规范的属性
  // （Chrome 151 Beta 才开始支持），默认值是 false——不显式打开的话，
  // 引擎只输出没有标点的原始文本，这正是之前 Chrome 上没有标点的原因。
  // 打开后引擎会根据停顿、语调、语法结构自动推断插入标点和首字母大写。
  // 用 in 做特性检测：旧版本浏览器没有这个属性时，赋值是无害的
  // no-op（不会报错，只是不生效），不影响其它功能正常运行。
  if ('unspokenPunctuation' in recognition) {
    recognition.unspokenPunctuation = true;
  }

  let finalTranscript = crossRoundAccumulatedText || "";

  // 【新增】检测“同一个未定稿索引内容被引擎悄悄重置”——超长无停顿语音
  // 场景下，SODA 在同一个 resultIndex 内部有时会让未定稿显示突然从一
  // 长串缩水成个位数字符。
  // 【重要教训，实测验证过】骤降不代表内容真的永久丢了——实测里骤降后
  // 索引往往会自己重新长回来、最终正常 isFinal 定稿，而且定稿内容基本
  // 等同于骤降前的那一长串（引擎内部其实一直留着，只是未定稿显示这层
  // 临时抽风了）。如果一检测到骤降就立刻把之前的内容强制归档，等它
  // 之后又正常定稿，就会出现两条几乎一样的内容重复显示。
  // 所以现在改成“延迟确认”：骤降时不立刻抢救，先挂起等一段时间——
  // 期间只要这个索引还有任何后续动静（不管是继续长大还是正常定稿），
  // 就说明它没有被真正放弃，取消抢救；只有等满这段时间、这个索引彻底
  // 没有任何后续消息了，才确认是真的被放弃，这时候才抢救。
  const RESCUE_MIN_PREV_LENGTH = 100; // 缓存内容至少要有这么长，才值得被“突然变短”这个判断盯上
  const RESCUE_MAX_NEW_LENGTH  = 50;  // 新内容如果只剩这么短（个位数字符/单词量级），判定为疑似骤降
  const RESCUE_GRACE_MS        = 3000; // 骤降后最多等这么久，仍未追回长度就确认放弃、执行抢救
  let currentIndexCachedText = ""; // 当前 resultIndex 目前为止见过的最长未定稿内容
  let currentIndexTrackedAt  = -1; // 上面这份缓存是哪个 resultIndex 的，索引变了要重新开始缓存
  let pendingRescue = null; // { index, timer, droppedText, droppedLength } —— 挂起中、等待确认是否真的需要抢救的骤降事件

  function cancelPendingRescue(reason) {
    if (pendingRescue) {
      console.log(`[诊断][抢救机制] resultIndex=${pendingRescue.index} 取消挂起的抢救（原因：${reason}）`);
      clearTimeout(pendingRescue.timer);
      pendingRescue = null;
    }
  }

  // 执行真正的抢救：把骤降前的内容强制当作定稿推进历史区。timer 到期
  // 和“定稿了但长度没追上”这两个触发点都会调用这里，抽成一个函数避免
  // 重复代码。
  function doRescue(rescue, reasonText) {
    console.warn(
      `[Offscreen] resultIndex=${rescue.index} ${reasonText}，确认被丢弃内容没有找回，强制归档抢救内容: "${rescue.droppedText}"`
    );
    pushQueue = pushQueue
      .then(() => pushResult(rescue.droppedText, sourceLang, true, rescue.index))
      .catch(err => {
        console.error("[Offscreen] pushResult 队列出错（抢救内容-延迟确认）:", err);
      });
  }

  // 【新增】pushResult 执行队列：保证多条“定稿”字幕严格按 onresult
  // 触发的先后顺序依次显示，不会因为某一条翻译得快就抢先跑到前面去。
  // 只有定稿才会进这条队列（未定稿的临时文字直接立即执行，不排队，
  // 详见下方 onresult 里的分支说明）。
  //
  // 背景：上一轮修复“大段对话重复”的 bug 时，把 finalTranscript 的清零
  // 从 await pushResult() 之后挪到了之前（同步执行）。这解决了重复问题，
  // 但也带来一个副作用——原来“清零写在 await 后面”这个写法，虽然导致了
  // 重复 bug，但也意外让下一次 onresult 的处理必须等上一次 pushResult()
  // 完全跑完才能继续，客观上让多条字幕严格排队显示。挪到 await 之前后，
  // onresult 不再等待就会继续处理下一个事件，多个 pushResult() 可能
  // 同时在跑，而每次翻译耗时会因为文本长短不同而不同（长句子明显更慢），
  // 结果后触发但内容更短的一句，翻译更快跑完，反而比先触发的长句子先
  // 显示出来，造成“显示顺序错乱”。
  // 用 pushQueue 这条 Promise 链条把定稿的 pushResult 调用串成队列，
  // 保证哪怕单次翻译耗时不同，也一定按 onresult 触发的先后顺序依次
  // 执行完、依次上屏——这样既保留了“清零同步执行、不重复”的优点，
  // 又不会乱序，也不会拖慢未定稿的实时显示。
  let pushQueue = Promise.resolve();

  recognition.onstart = () => {
    console.log("[Offscreen] SpeechRecognition 已启动，语言:", recognition.lang);
  };

  recognition.onresult = (event) => {
    const currentIndex = event.resultIndex;
    const currentIndexResult = event.results[currentIndex];
    const isCurrentFinal = !!currentIndexResult?.isFinal;
    const currentIndexText = currentIndexResult?.[0]?.transcript || "";

    // 【修正】原来的逻辑是“只要这个索引还有任何后续动静就取消抢救”，
    // 这里有个真实的漏洞：如果被丢弃后，引擎压根没找回原来的内容，
    // 只是从骤降那一刻开始识别一段全新的、无关的内容，然后就这么正常
    // 定稿了——旧逻辑会因为“收到了后续消息”就误判成“不用抢救”，被
    // 丢弃的那段就永久消失了。
    // 正确的判断标准应该是“内容长度有没有追回到骤降前的水平”，而不是
    // “有没有任何动静”：
    //   - 长度追上了 → 引擎真的把内容找回来了，取消抢救；
    //   - 长度没追上，但还没定稿 → 继续挂起等，可能还在追；
    //   - 长度没追上，且已经定稿了 → 不用再等，可以确定被丢弃的内容
    //     不会再回来了，立即抢救，不用等挂起时间到期。
    if (pendingRescue && pendingRescue.index === currentIndex) {
      if (currentIndexText.length >= pendingRescue.droppedLength) {
        cancelPendingRescue(`内容长度(${currentIndexText.length})已追回到骤降前的水平(${pendingRescue.droppedLength})，判定引擎自己找回来了`);
      } else if (isCurrentFinal) {
        doRescue(pendingRescue, `已经定稿但长度(${currentIndexText.length})仍未追上骤降前的长度(${pendingRescue.droppedLength})`);
        cancelPendingRescue('已立即执行抢救，不需要再等挂起时间到期');
      }
      // 否则：还没定稿、长度也还没追上——继续挂起，不做任何处理，
      // 让它自己继续长，或者等挂起时间到期后由 timer 里的兜底逻辑处理。
    }

    // 索引变了（正常翻到下一句），缓存基准要重新开始，不能拿上一句的
    // 长度来跟这一句比较。
    if (currentIndex !== currentIndexTrackedAt) {
      currentIndexCachedText = "";
      currentIndexTrackedAt  = currentIndex;
    }

    // 【新增】骤降检测：同一个索引内，还没定稿，但内容突然从一长串
    // 缩水成个位数——正常的未定稿更新只会越来越长（我们这么多轮诊断
    // 日志里从没见过反例），这种断崖式缩短不是正常现象。检测到了先
    // 挂起等一等，不立刻抢救（详见上方大段说明）。
    if (
      !isCurrentFinal &&
      currentIndexCachedText.length >= RESCUE_MIN_PREV_LENGTH &&
      currentIndexText.length <= RESCUE_MAX_NEW_LENGTH
    ) {
      const textAtShrinkTime  = currentIndexCachedText;
      const indexAtShrinkTime = currentIndex;
      console.warn(
        `[Offscreen] 检测到 resultIndex=${indexAtShrinkTime} 内容突然从"${textAtShrinkTime}"（${textAtShrinkTime.length}字）缩短为"${currentIndexText}"（${currentIndexText.length}字），挂起等待最多 ${RESCUE_GRACE_MS}ms，期间会持续检查长度有没有追回来`
      );
      pendingRescue = {
        index: indexAtShrinkTime,
        droppedText: textAtShrinkTime,
        droppedLength: textAtShrinkTime.length,
        timer: setTimeout(() => {
          // 走到这里说明挂起期间这个索引的内容长度始终没能追回到
          // 骤降前的水平（否则早就在上面被取消了），确认是真的丢了。
          if (pendingRescue && pendingRescue.index === indexAtShrinkTime) {
            doRescue(pendingRescue, `挂起 ${RESCUE_GRACE_MS}ms 后长度仍未追回`);
            pendingRescue = null;
          }
        }, RESCUE_GRACE_MS),
      };
    }

    // 更新缓存：只要还没定稿，就把这次看到的内容当作“目前为止最长版本”
    // 存起来（正常情况下内容只会越来越长，直接覆盖存最新的就等于存最长的）。
    currentIndexCachedText = isCurrentFinal ? "" : currentIndexText;

    let interimTranscript = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += transcript;
      } else {
        interimTranscript += transcript;
      }
    }
    crossRoundAccumulatedText = finalTranscript;
    // isFinal（句子被引擎判定为完整）时才 break，触发历史区归档
    const hasFinalThisRound = event.results[event.resultIndex]?.isFinal;
    const textToPush = finalTranscript + interimTranscript;

    // 【新增】onresult 总览诊断日志：每次触发都打一条，带上 resultIndex，
    // 方便跟历史区/未定稿区实际显示的内容对照，排查任何丢失/错位/重复
    // 问题时的第一手依据。
    console.log(
      `[诊断][onresult] resultIndex=${currentIndex} results.length=${event.results.length} isFinal=${!!hasFinalThisRound} 本次内容="${currentIndexText}"`
    );

    if (hasFinalThisRound) {
      // 【关键修复 1】必须在任何 await 之前、同步地把 finalTranscript
      // 清零，不能等翻译跑完再清——避免“大段对话时内容重复累积”的
      // 竞态条件，详见上方注释。
      finalTranscript = "";

      // 【关键修复 2】只有“定稿”才需要进队列排队——只有定稿会触发翻译
      // （见 pushResult 内部逻辑），也只有定稿的先后顺序会影响历史区
      // 的显示顺序。接到队列末尾而不是直接 await，保证哪怕单次翻译
      // 耗时不同（长句子明显更慢），也一定按 onresult 触发的先后顺序
      // 依次上屏，不会因为某次翻译更快就插队。
      pushQueue = pushQueue
        .then(() => pushResult(textToPush, sourceLang, true, currentIndex))
        .catch(err => {
          // 单次翻译/上屏出错不该导致后面所有排队的字幕全部卡死，
          // 这里吞掉错误，让队列可以继续处理后面的内容。
          console.error("[Offscreen] pushResult 队列出错:", err);
        });
    } else {
      // 【改动】未定稿的临时文字不需要排队——pushResult 对未定稿的情况
      // 本来就不会触发翻译（直接返回空字符串，见 pushResult 内部逻辑），
      // 几乎是立即完成的。如果也塞进上面那条队列，一旦队列头部卡着一次
      // 耗时较长的定稿翻译，未定稿的“实时跳动”效果就会被一起拖慢、
      // 出现明显卡顿。这里直接立即执行，不经过队列，跟排队的定稿翻译
      // 互不影响。
      pushResult(textToPush, sourceLang, false, currentIndex).catch(err => {
        console.error("[Offscreen] pushResult（未定稿）出错:", err);
      });
    }
  };

  // 标记本轮识别是否遇到了“重启也没用”的致命错误（语言不支持、权限被拒等）。
  // 用闭包变量而不是外层状态，是因为每次 startRecognition() 都会创建新的
  // recognition 实例，fatal 状态天然只属于这一轮。
  let fatalError = false;
  let langNotSupported = false; // 单独标记，只有这种情况才该归咎于“这个语言”

  recognition.onerror = (event) => {
    if (event.error === 'no-speech') return; // 静音片段，非真正错误，忽略
    console.error("[Offscreen] Recognition error:", event.error);

    // 这几类错误不会因为重启而自愈，继续自动重启只会死循环刷错误，
    // 必须在 onend 里拦下来，直接停止而不是重试。
    const fatalErrors = new Set(['language-not-supported', 'not-allowed', 'audio-capture']);
    if (fatalErrors.has(event.error)) fatalError = true;
    if (event.error === 'language-not-supported') langNotSupported = true;

    const commonErrorMessages = {
      "audio-capture": "未能获取到音频输入（tabCapture 轨道异常）。",
      "not-allowed": "音频输入权限被拒绝。",
      "language-not-supported": "所选语言不受当前浏览器的离线识别支持（available() 检测结果与实际 start() 结果不一致，这是当前浏览器版本的已知不稳定行为，不是插件的 bug）。",
      "network": "在线识别所需的网络不可用（processLocally 模式下不应出现，如出现请检查浏览器版本）。",
    };
    const message = commonErrorMessages[event.error] || `语音识别错误: ${event.error}`;
    port.postMessage({ type: 'subtitle-result', status: 'error', error: message });
  };

  recognition.onend = () => {
    console.log("[Offscreen] Recognition ended");
    if (stopRequested) return;

    if (fatalError) {
      // 致命错误：不重启，同时把这个语言从“已就绪”缓存里清掉，
      // 下次用户重新点 Start 时会重新走一遍 available() 检测，
      // 而不是直接信任一个刚刚被证明不可靠的缓存结果。
      console.warn("[Offscreen] 遇到致命错误，停止自动重启");
      readyLangs.delete(recognition.lang);
      // language-not-supported 才记为“这个语言在本次会话里已知打不开”，
      // not-allowed/audio-capture 是权限或硬件层面的问题，跟语言本身无关，
      // 不该一并连坐（比如用户下次授权了麦克风权限，可能就好了）。
      if (langNotSupported) knownBrokenLangs.add(recognition.lang);
      stopRequested = true;
      recorder.stopCapture();
      currentTrack = null;
      stopHeartbeat();
      port.postMessage({ type: 'subtitle-result', status: 'stopped' });
      return;
    }

    // SODA 的 continuous 模式在长静音或内部限制下仍可能触发 onend，
    // 这里做自动重启以保持“持续识别”的体验（对齐原 Voxtral 管线的自动重启轮次逻辑）。
    setTimeout(() => {
      if (!stopRequested && currentTrack) {
        try {
          recognition.start(currentTrack);
        } catch (e) {
          console.warn("[Offscreen] 自动重启识别失败:", e.message);
        }
      }
    }, 300);
  };

  recognition.start(track);
}

// ── 指令处理 ──────────────────────────────────────────────────
function handleStartRecording(msg) {
  if (msg.targetLanguage) targetLanguage = msg.targetLanguage;

  stopRequested = false;
  crossRoundAccumulatedText = "";
  lastDetectedLang = null; // 新会话开始，上一次识别出的语言不该带到这次

  const sourceLang = msg.language || 'en';
  const bcpLang = toBcp47(sourceLang);

  (async () => {
    try {
      const ready = await ensureModelReady(bcpLang);
      if (!ready) return; // 错误已通过 port 上报

      // 【改回】Translator API 是按“语言对”分别创建实例的（不像 LLM
      // 是一个通用 pipeline），这里只能给用户选的这个“提示语言”预热一下，
      // 让最常见的情况（识别结果确实就是用户选的这个语言）第一条定稿
      // 结果不用等 Translator.create() 的创建耗时。如果实际检测出来是
      // 别的语言，translateText() 里会按需再创建对应语言对的翻译器。
      if (sourceLang !== targetLanguage) {
        prepareTranslator(sourceLang, targetLanguage);
      }

      currentTrack = await recorder.startCapture(msg.data);
      startHeartbeat();
      startRecognition(sourceLang, currentTrack);
    } catch (err) {
      console.error("[Offscreen] 启动失败:", err.message);
      port.postMessage({ type: 'subtitle-result', status: 'error', error: err.message });
    }
  })();
}

function handleStopRecording() {
  stopHeartbeat();
  stopRequested = true;

  if (recognition) {
    try { recognition.stop(); } catch (_) {}
    recognition = null;
  }

  recorder.stopCapture();
  currentTrack = null;

  port.postMessage({ type: 'subtitle-result', status: 'stopped' });
}

console.log("[Offscreen] 页面已加载（SpeechRecognition / SODA 模式）");